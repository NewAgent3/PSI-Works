@echo off
REM Windows launcher for the game client
cd /d "%~dp0"
set /p HOST="Server IP (default 127.0.0.1): "
if "%HOST%"=="" set HOST=127.0.0.1
set /p NAME="Your name: "
if "%NAME%"=="" set NAME=Player
python client\client.py --host %HOST% --name "%NAME%"
pause
