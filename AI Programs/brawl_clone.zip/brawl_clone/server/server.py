"""
Brawl Clone - Authoritative Multiplayer Server
================================================
Pure Python stdlib WebSocket-like server using asyncio + simple JSON-line protocol
over TCP. Handles up to N players, projectiles, damage, respawn, scoreboard.

Run:  python server.py [--host 0.0.0.0] [--port 5555]
"""
import asyncio
import json
import math
import random
import time
import argparse
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Tuple

TICK_RATE = 30          # server ticks per second
ARENA_RADIUS = 28.0     # circular arena
RESPAWN_TIME = 4.0
PROJECTILE_LIFETIME = 1.5
WALL_COUNT = 14         # cover boxes
BUSH_COUNT = 10         # stealth bushes


# ---------- Character archetypes (Brawl-Stars style stats) ----------
BRAWLERS = {
    "spike":  {"hp": 700,  "speed": 6.2, "dmg": 70,  "fire_rate": 0.55, "range": 18, "proj_speed": 22, "spread": 0.0,  "shots": 1, "color": [0, 1, 0]},
    "edgar":  {"hp": 1100, "speed": 8.0, "dmg": 110, "fire_rate": 0.40, "range": 6,  "proj_speed": 30, "spread": 0.0,  "shots": 1, "color": [1, 0, 0.4]},
    "buzz":   {"hp": 1000, "speed": 6.6, "dmg": 90,  "fire_rate": 0.50, "range": 7,  "proj_speed": 28, "spread": 0.0,  "shots": 1, "color": [1, 0.8, 0]},
    "damian": {"hp": 900,  "speed": 6.0, "dmg": 80,  "fire_rate": 0.60, "range": 14, "proj_speed": 22, "spread": 0.0,  "shots": 1, "color": [0.6, 0, 1]},
    "lumi":   {"hp": 650,  "speed": 6.4, "dmg": 95,  "fire_rate": 0.70, "range": 22, "proj_speed": 26, "spread": 0.0,  "shots": 1, "color": [1, 0.9, 0.4]},
    "sirius": {"hp": 750,  "speed": 6.2, "dmg": 85,  "fire_rate": 0.65, "range": 20, "proj_speed": 24, "spread": 0.0,  "shots": 1, "color": [0.2, 0.4, 1]},
    "alli":   {"hp": 800,  "speed": 6.3, "dmg": 75,  "fire_rate": 0.55, "range": 16, "proj_speed": 22, "spread": 0.0,  "shots": 1, "color": [0, 0.8, 1]},
    "kaze":   {"hp": 700,  "speed": 6.8, "dmg": 60,  "fire_rate": 0.35, "range": 12, "proj_speed": 26, "spread": 0.0,  "shots": 1, "color": [1, 0.3, 0.6]},
    "kit":    {"hp": 850,  "speed": 6.5, "dmg": 70,  "fire_rate": 0.50, "range": 13, "proj_speed": 24, "spread": 0.15, "shots": 3, "color": [1, 0.6, 0.3]},
}


@dataclass
class Player:
    pid: int
    name: str
    brawler: str
    x: float = 0.0
    z: float = 0.0
    yaw: float = 0.0
    hp: float = 1000
    max_hp: float = 1000
    speed: float = 6.0
    alive: bool = True
    respawn_at: float = 0.0
    kills: int = 0
    deaths: int = 0
    last_shot: float = 0.0
    writer: object = None
    in_bush: bool = False
    moving: bool = False


@dataclass
class Projectile:
    oid: int
    owner: int
    x: float
    z: float
    vx: float
    vz: float
    dmg: float
    born: float
    lifetime: float
    color: list


@dataclass
class Wall:
    x: float
    z: float
    w: float = 2.0
    h: float = 2.0


@dataclass
class Bush:
    x: float
    z: float
    r: float = 2.0


class GameServer:
    def __init__(self, host="0.0.0.0", port=5555):
        self.host = host
        self.port = port
        self.players: Dict[int, Player] = {}
        self.projectiles: List[Projectile] = []
        self.walls: List[Wall] = []
        self.bushes: List[Bush] = []
        self.next_pid = 1
        self.next_oid = 1
        self.start_time = time.time()
        self._gen_map()

    def _gen_map(self):
        rng = random.Random(42)
        # Symmetrical-ish wall layout
        positions = []
        for _ in range(WALL_COUNT):
            for _ in range(40):
                x = rng.uniform(-ARENA_RADIUS + 4, ARENA_RADIUS - 4)
                z = rng.uniform(-ARENA_RADIUS + 4, ARENA_RADIUS - 4)
                if math.hypot(x, z) < 5:  # leave center open
                    continue
                if all(math.hypot(x - px, z - pz) > 4 for px, pz in positions):
                    positions.append((x, z))
                    self.walls.append(Wall(x, z))
                    break
        for _ in range(BUSH_COUNT):
            for _ in range(40):
                x = rng.uniform(-ARENA_RADIUS + 3, ARENA_RADIUS - 3)
                z = rng.uniform(-ARENA_RADIUS + 3, ARENA_RADIUS - 3)
                if all(math.hypot(x - w.x, z - w.z) > 3 for w in self.walls) and \
                   all(math.hypot(x - b.x, z - b.z) > 4 for b in self.bushes):
                    self.bushes.append(Bush(x, z))
                    break

    def spawn_point(self) -> Tuple[float, float]:
        angle = random.uniform(0, math.tau)
        r = ARENA_RADIUS - 3
        return math.cos(angle) * r, math.sin(angle) * r

    def _in_wall(self, x: float, z: float, radius=0.6) -> bool:
        for w in self.walls:
            if abs(x - w.x) < w.w / 2 + radius and abs(z - w.z) < w.h / 2 + radius:
                return True
        return False

    async def handle_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        pid = self.next_pid
        self.next_pid += 1
        addr = writer.get_extra_info("peername")
        print(f"[+] Connection from {addr} -> pid={pid}")

        # First message must be JOIN
        try:
            line = await asyncio.wait_for(reader.readline(), timeout=10)
            msg = json.loads(line.decode().strip())
            if msg.get("t") != "join":
                writer.close()
                return
            name = msg.get("name", f"Player{pid}")[:16]
            brawler = msg.get("brawler", "spike")
            if brawler not in BRAWLERS:
                brawler = "spike"
        except Exception as e:
            print(f"[!] Join failed: {e}")
            writer.close()
            return

        stats = BRAWLERS[brawler]
        sx, sz = self.spawn_point()
        p = Player(
            pid=pid, name=name, brawler=brawler,
            x=sx, z=sz, yaw=0.0,
            hp=stats["hp"], max_hp=stats["hp"], speed=stats["speed"],
            writer=writer,
        )
        self.players[pid] = p

        # Send welcome with map + own pid
        await self._send(writer, {
            "t": "welcome",
            "pid": pid,
            "walls": [asdict(w) for w in self.walls],
            "bushes": [asdict(b) for b in self.bushes],
            "arena": ARENA_RADIUS,
            "brawlers": BRAWLERS,
        })

        try:
            async for raw in reader:
                if not raw:
                    break
                try:
                    msg = json.loads(raw.decode().strip())
                except Exception:
                    continue
                await self.handle_msg(p, msg)
        except (ConnectionResetError, BrokenPipeError):
            pass
        finally:
            print(f"[-] pid={pid} ({p.name}) disconnected")
            self.players.pop(pid, None)
            try:
                writer.close()
            except Exception:
                pass

    async def _send(self, writer, obj):
        try:
            writer.write((json.dumps(obj) + "\n").encode())
            await writer.drain()
        except Exception:
            pass

    async def handle_msg(self, p: Player, msg: dict):
        t = msg.get("t")
        if t == "input":
            # client sends desired position (predicted) + yaw; server validates
            if not p.alive:
                return
            dx = float(msg.get("dx", 0))
            dz = float(msg.get("dz", 0))
            dt = float(msg.get("dt", 1 / TICK_RATE))
            dt = max(0.001, min(0.1, dt))
            ln = math.hypot(dx, dz)
            if ln > 1e-4:
                dx /= ln; dz /= ln
                p.moving = True
            else:
                p.moving = False
            step = p.speed * dt
            nx = p.x + dx * step
            nz = p.z + dz * step
            # arena bounds (circular)
            if math.hypot(nx, nz) > ARENA_RADIUS - 0.6:
                # slide along boundary
                pass
            else:
                # collision with walls (try x and z separately to slide)
                if not self._in_wall(nx, p.z):
                    p.x = nx
                if not self._in_wall(p.x, nz):
                    p.z = nz
            p.yaw = float(msg.get("yaw", p.yaw))
            # bush check
            p.in_bush = any(math.hypot(p.x - b.x, p.z - b.z) < b.r for b in self.bushes)

        elif t == "shoot":
            if not p.alive:
                return
            now = time.time()
            stats = BRAWLERS[p.brawler]
            if now - p.last_shot < stats["fire_rate"]:
                return
            p.last_shot = now
            yaw = float(msg.get("yaw", p.yaw))
            # leaving bush by shooting
            p.in_bush = False
            shots = stats["shots"]
            spread = stats["spread"]
            base = yaw
            for i in range(shots):
                if shots == 1:
                    a = base
                else:
                    a = base + (i - (shots - 1) / 2) * spread
                vx = math.sin(a) * stats["proj_speed"]
                vz = math.cos(a) * stats["proj_speed"]
                self.projectiles.append(Projectile(
                    oid=self.next_oid, owner=p.pid,
                    x=p.x + math.sin(a) * 0.9,
                    z=p.z + math.cos(a) * 0.9,
                    vx=vx, vz=vz,
                    dmg=stats["dmg"],
                    born=now,
                    lifetime=min(PROJECTILE_LIFETIME, stats["range"] / stats["proj_speed"]),
                    color=stats["color"],
                ))
                self.next_oid += 1

    async def tick(self):
        dt = 1.0 / TICK_RATE
        now = time.time()
        # Projectiles
        alive_projs = []
        for pr in self.projectiles:
            if now - pr.born > pr.lifetime:
                continue
            pr.x += pr.vx * dt
            pr.z += pr.vz * dt
            # wall collision
            if self._in_wall(pr.x, pr.z, radius=0.1):
                continue
            if math.hypot(pr.x, pr.z) > ARENA_RADIUS:
                continue
            # player hits
            hit = False
            for tgt in self.players.values():
                if tgt.pid == pr.owner or not tgt.alive:
                    continue
                if math.hypot(tgt.x - pr.x, tgt.z - pr.z) < 0.8:
                    tgt.hp -= pr.dmg
                    hit = True
                    if tgt.hp <= 0:
                        tgt.alive = False
                        tgt.deaths += 1
                        tgt.respawn_at = now + RESPAWN_TIME
                        if pr.owner in self.players:
                            self.players[pr.owner].kills += 1
                    break
            if not hit:
                alive_projs.append(pr)
        self.projectiles = alive_projs

        # Respawn
        for p in self.players.values():
            if not p.alive and now >= p.respawn_at:
                p.alive = True
                stats = BRAWLERS[p.brawler]
                p.hp = stats["hp"]
                p.x, p.z = self.spawn_point()

        # Broadcast state
        state = {
            "t": "state",
            "ts": now,
            "players": [
                {
                    "pid": pl.pid, "name": pl.name, "brawler": pl.brawler,
                    "x": round(pl.x, 3), "z": round(pl.z, 3), "yaw": round(pl.yaw, 3),
                    "hp": round(pl.hp, 1), "max_hp": pl.max_hp,
                    "alive": pl.alive, "kills": pl.kills, "deaths": pl.deaths,
                    "in_bush": pl.in_bush, "moving": pl.moving,
                    "respawn_in": max(0.0, round(pl.respawn_at - now, 2)) if not pl.alive else 0,
                }
                for pl in self.players.values()
            ],
            "projectiles": [
                {"oid": pr.oid, "x": round(pr.x, 2), "z": round(pr.z, 2), "color": pr.color}
                for pr in self.projectiles
            ],
        }
        data = (json.dumps(state) + "\n").encode()
        dead = []
        for pid, pl in self.players.items():
            try:
                pl.writer.write(data)
                await pl.writer.drain()
            except Exception:
                dead.append(pid)
        for pid in dead:
            self.players.pop(pid, None)

    async def run(self):
        server = await asyncio.start_server(self.handle_client, self.host, self.port)
        sockets = server.sockets or []
        for s in sockets:
            print(f"[server] listening on {s.getsockname()}")
        print(f"[server] tick rate = {TICK_RATE} Hz, arena radius = {ARENA_RADIUS}")
        async def ticker():
            interval = 1.0 / TICK_RATE
            next_t = time.time()
            while True:
                await self.tick()
                next_t += interval
                sleep = next_t - time.time()
                if sleep > 0:
                    await asyncio.sleep(sleep)
                else:
                    next_t = time.time()
        async with server:
            await asyncio.gather(server.serve_forever(), ticker())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=5555)
    args = ap.parse_args()
    srv = GameServer(args.host, args.port)
    try:
        asyncio.run(srv.run())
    except KeyboardInterrupt:
        print("\n[server] shutting down")


if __name__ == "__main__":
    main()
