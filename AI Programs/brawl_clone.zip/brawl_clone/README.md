# Brawl Clone — Python 3D Multiplayer Arena (Brawl Stars-inspired)

A fan-made, non-commercial 3D top-down arena shooter inspired by Supercell's Brawl
Stars, written entirely in **Python** with the **Ursina** engine on top of Panda3D.
It uses the 9 character models you provided (Damian, Edgar, Spike, Buzz, Alli,
Kaze, Lumi, Sirius, Kit) and ships with a custom authoritative multiplayer server
written in pure-stdlib `asyncio` (no extra deps for the server).

> ⚠️ **Legal note.** *Brawl Stars* and its characters are © Supercell. This project
> is a personal/educational fan recreation for learning purposes only — do not
> distribute commercially.

---

## Why this stack

* **Python** → cross-platform, fast iteration, runs on any Windows machine that
  has Python installed.
* **Ursina (Panda3D)** → batteries-included 3D engine, loads `.glb` directly,
  pip-installable, works on Windows out of the box.
* **Custom asyncio TCP server** → tiny, deterministic, authoritative; no
  external packages needed for the server. Works over LAN or the open internet
  if you forward port 5555.

---

## Project layout

```
brawl_clone/
├── assets/
│   ├── fbx/         # original FBX models (one per brawler)
│   ├── glb/         # auto-converted GLB models (loaded by Ursina)
│   └── textures/    # diffuse textures
├── server/server.py # authoritative multiplayer server
├── client/client.py # Ursina 3D client
├── requirements.txt
├── install.bat
├── launch_server.bat
└── launch_client.bat
```

---

## First-time setup (Windows)

1. Install **Python 3.10+** (https://www.python.org/) — make sure to tick *"Add
   python.exe to PATH"* in the installer.
2. Double-click **`install.bat`** to install Ursina + Panda3D.

That's it. No Blender / no compilation needed — the GLB files in `assets/glb/`
are already prepared from your FBX zips.

---

## Playing

### Single machine (just you, for testing)

1. Double-click **`launch_server.bat`** — keep that window open.
2. Double-click **`launch_client.bat`** — press *Enter* on the prompts to
   accept defaults, then pick a brawler.
3. Open another **`launch_client.bat`** with a different name to bot-test
   against yourself.

### LAN multiplayer

1. On the host PC, run `launch_server.bat`. Find your LAN IP (`ipconfig` →
   IPv4 Address, e.g. `192.168.1.42`).
2. Make sure Windows Firewall allows Python on port `5555` (it'll prompt you
   the first time).
3. On every other PC on the same network, run `launch_client.bat` and enter
   the host's IP.

### Internet multiplayer

Forward TCP port `5555` on your router to the host PC, give friends your
public IP. Or run the server on a small VPS — it's pure stdlib Python, runs
on anything.

---

## Controls

| Action       | Key                                  |
|--------------|--------------------------------------|
| Move         | **W A S D** or arrow keys            |
| Aim          | Mouse (ground cursor)                |
| Shoot        | **Left click** or **Space**          |
| Scoreboard   | Hold **Tab**                         |
| Quit         | Close window / Alt-F4                |

---

## The 9 brawlers

Stats roughly mirror Brawl Stars archetypes:

| Brawler | HP   | Speed | Damage | Fire rate | Range | Notes                  |
|---------|------|-------|--------|-----------|-------|------------------------|
| Spike   | 700  | 6.2   | 70     | 0.55 s    | 18    | Glass-cannon sniper    |
| Edgar   | 1100 | 8.0   | 110    | 0.40 s    | 6     | Melee assassin         |
| Buzz    | 1000 | 6.6   | 90     | 0.50 s    | 7     | Bruiser                |
| Damian  | 900  | 6.0   | 80     | 0.60 s    | 14    | Mid-range fighter      |
| Lumi    | 650  | 6.4   | 95     | 0.70 s    | 22    | Long-range sniper      |
| Sirius  | 750  | 6.2   | 85     | 0.65 s    | 20    | Marksman               |
| Alli    | 800  | 6.3   | 75     | 0.55 s    | 16    | Balanced               |
| Kaze    | 700  | 6.8   | 60     | 0.35 s    | 12    | Fast attacker          |
| Kit     | 850  | 6.5   | 70     | 0.50 s    | 13    | 3-shot spread          |

---

## Gameplay features

* Authoritative server — clients cannot hack health/position
* Up to ~16 players per match (TCP, JSON-line protocol, 30 Hz tick)
* Circular arena with:
  * Destructible-style cover crates (walls)
  * Bushes that hide you from enemies (you go translucent + 🌿 tag)
  * Out-of-bounds protection
* Per-brawler stats (HP, speed, damage, fire-rate, range, projectile spread)
* Real-time projectiles with wall collision
* Health bars + name tags floating above each brawler
* Respawn timer (4 s)
* Live scoreboard (K/D)
* Isometric chase camera that follows your brawler
* Lerp-smoothed remote players

---

## Architecture in one paragraph

The **server** (`server/server.py`) is the source of truth. It runs at 30 Hz,
receives `input` packets (movement vector + aim yaw) from each client, applies
movement with arena/wall collision, advances projectiles, resolves damage,
handles respawns, and broadcasts a full state snapshot every tick. The
**client** (`client/client.py`) does dead-simple client-side prediction by
sending its desired movement vector each frame and then snapping/lerping
toward the server's authoritative position. Projectiles are spawned by the
server only — clients just render them.

---

## Troubleshooting

* **"ModuleNotFoundError: ursina"** — run `install.bat`.
* **Black window / model is invisible** — your GPU driver might not like
  Panda3D's default GL path. Try updating GPU drivers, or set
  `PANDA_PRC_PATH` to use DirectX (advanced).
* **"Could not connect"** — server isn't running, wrong IP, or Windows
  Firewall blocked port 5555.
* **Models look untextured** — the GLB and the PNG live in different
  folders; the client auto-applies the matching texture. If it doesn't
  render, check `assets/textures/{brawler}.png` exists.

---

Enjoy! 🎮
