"""
Brawl Clone - 3D Client (Ursina)
=================================
Top-down/isometric multiplayer arena shooter inspired by Brawl Stars.
Loads GLB character models, connects to authoritative server, renders state.

Run:  python client.py [--host 127.0.0.1] [--port 5555] [--name You] [--brawler spike]
Controls:
  WASD / arrows   = move
  Mouse           = aim (cursor on ground)
  Left click / SPACE = shoot
  TAB             = scoreboard
  ESC             = quit
"""
import argparse
import json
import math
import os
import socket
import sys
import threading
import time
from pathlib import Path

# Ursina import with friendly error
try:
    from ursina import (
        Ursina, Entity, camera, color, window, mouse, application,
        held_keys, time as utime, Vec3, Vec2, Text, raycast, scene,
        invoke, destroy, AmbientLight, DirectionalLight, EditorCamera,
        Sky,
    )
    from ursina.prefabs.health_bar import HealthBar
except ImportError:
    print("Ursina not installed. Run: pip install ursina")
    sys.exit(1)

ASSETS_DIR = Path(__file__).resolve().parent.parent / "assets"
GLB_DIR = ASSETS_DIR / "glb"
TEX_DIR = ASSETS_DIR / "textures"

# --- networking ---------------------------------------------------------
class NetClient:
    def __init__(self, host, port, name, brawler):
        self.host = host
        self.port = port
        self.name = name
        self.brawler = brawler
        self.sock = None
        self.file = None
        self.buf = b""
        self.lock = threading.Lock()
        self.state = {"players": [], "projectiles": []}
        self.welcome = None
        self.my_pid = -1
        self.connected = False
        self.error = None

    def connect(self):
        try:
            self.sock = socket.create_connection((self.host, self.port), timeout=5)
            self.sock.settimeout(None)
            self.file = self.sock.makefile("rwb")
            self._send({"t": "join", "name": self.name, "brawler": self.brawler})
            # wait welcome
            line = self.file.readline()
            if not line:
                self.error = "Server closed connection"
                return False
            self.welcome = json.loads(line.decode().strip())
            self.my_pid = self.welcome["pid"]
            self.connected = True
            t = threading.Thread(target=self._reader, daemon=True)
            t.start()
            return True
        except Exception as e:
            self.error = str(e)
            return False

    def _send(self, obj):
        try:
            data = (json.dumps(obj) + "\n").encode()
            self.sock.sendall(data)
        except Exception as e:
            self.error = str(e)

    def send_input(self, dx, dz, dt, yaw):
        self._send({"t": "input", "dx": dx, "dz": dz, "dt": dt, "yaw": yaw})

    def send_shoot(self, yaw):
        self._send({"t": "shoot", "yaw": yaw})

    def _reader(self):
        try:
            while True:
                line = self.file.readline()
                if not line:
                    self.error = "Disconnected from server"
                    self.connected = False
                    return
                try:
                    msg = json.loads(line.decode().strip())
                except Exception:
                    continue
                if msg.get("t") == "state":
                    with self.lock:
                        self.state = msg
        except Exception as e:
            self.error = str(e)
            self.connected = False


# --- 3D scene -----------------------------------------------------------
class PlayerView:
    def __init__(self, pid, brawler, brawler_stats):
        self.pid = pid
        self.brawler = brawler
        glb_path = GLB_DIR / f"{brawler}.glb"
        # Ursina expects model name relative to its load path; we'll pass absolute string
        try:
            self.entity = Entity(
                model=str(glb_path),
                scale=0.012,
                position=(0, 0, 0),
                rotation=(0, 0, 0),
            )
            # Apply texture if present
            tex_path = TEX_DIR / f"{brawler}.png"
            if tex_path.exists():
                try:
                    self.entity.texture = str(tex_path)
                except Exception:
                    pass
        except Exception as e:
            print(f"[client] Failed to load {brawler} model: {e}")
            self.entity = Entity(model="cube", color=color.rgb(*brawler_stats["color"]),
                                 scale=(0.8, 1.6, 0.8))
        # Name + HP UI floating above
        self.name_text = Text(text="", parent=self.entity, position=(0, 130, 0),
                              scale=80, billboard=True, origin=(0, 0))
        self.hp_bar = Entity(parent=self.entity, model="quad", color=color.lime,
                             scale=(120, 14, 1), position=(0, 110, 0), billboard=True)
        self.hp_bg = Entity(parent=self.entity, model="quad", color=color.black66,
                            scale=(124, 16, 1), position=(0, 110, -0.1), billboard=True)
        self.target_x = 0.0
        self.target_z = 0.0
        self.target_yaw = 0.0
        self.alive = True

    def update_from(self, data, brawler_stats):
        self.target_x = data["x"]
        self.target_z = data["z"]
        self.target_yaw = data["yaw"]
        hp = max(0, data["hp"]) / max(1, data["max_hp"])
        # update hp bar (color from green to red)
        self.hp_bar.scale_x = 120 * hp
        if hp > 0.6:
            self.hp_bar.color = color.lime
        elif hp > 0.3:
            self.hp_bar.color = color.yellow
        else:
            self.hp_bar.color = color.red
        # name text
        suffix = ""
        if data.get("in_bush"):
            suffix = " 🌿"
        self.name_text.text = f"{data['name']}{suffix}"
        # visibility (alive)
        if data["alive"]:
            self.entity.enabled = True
            self.entity.alpha = 0.4 if data.get("in_bush") else 1.0
            for ch in self.entity.children:
                if hasattr(ch, "alpha"):
                    ch.alpha = self.entity.alpha
        else:
            self.entity.enabled = False
        self.alive = data["alive"]

    def lerp(self, dt):
        # smooth interp to server target
        k = min(1.0, dt * 14)
        self.entity.x += (self.target_x - self.entity.x) * k
        self.entity.z += (self.target_z - self.entity.z) * k
        # rotate (Ursina yaw is degrees around Y)
        target_deg = math.degrees(self.target_yaw)
        cur = self.entity.rotation_y
        diff = (target_deg - cur + 540) % 360 - 180
        self.entity.rotation_y = cur + diff * k

    def destroy(self):
        destroy(self.entity)


class ProjectileView:
    def __init__(self, oid, x, z, col):
        self.oid = oid
        self.entity = Entity(
            model="sphere",
            color=color.rgb(*[int(c * 255) for c in col]),
            scale=0.45,
            position=(x, 0.9, z),
        )
        # glow effect
        self.glow = Entity(
            parent=self.entity, model="sphere",
            color=color.rgba(int(col[0]*255), int(col[1]*255), int(col[2]*255), 80),
            scale=2.2,
        )

    def update(self, x, z):
        self.entity.x = x
        self.entity.z = z

    def destroy(self):
        destroy(self.entity)


class Game:
    def __init__(self, args):
        self.args = args
        self.app = Ursina(title="Brawl Clone", borderless=False, fullscreen=False,
                          development_mode=False, vsync=True)
        window.color = color.rgb(140, 200, 255)
        Sky(color=color.rgb(120, 180, 240))

        # Connect first
        self.net = NetClient(args.host, args.port, args.name, args.brawler)
        if not self.net.connect():
            print(f"[client] Could not connect: {self.net.error}")
            print(f"[client] Make sure the server is running: python server/server.py")
            sys.exit(1)

        self.brawler_stats = self.net.welcome["brawlers"]
        self.arena_r = self.net.welcome["arena"]

        self._build_world()

        self.player_views = {}     # pid -> PlayerView
        self.proj_views = {}       # oid -> ProjectileView
        self.aim_world = Vec3(0, 0, 1)
        self.show_scoreboard = False
        self.last_shot = 0
        self.last_input_send = 0

        # HUD
        self.hud_status = Text(text="", position=(-0.85, 0.45), scale=1.2,
                                color=color.white, background=True)
        self.hud_killfeed = Text(text="", position=(-0.85, 0.40), scale=0.9,
                                  color=color.yellow)
        self.hud_center = Text(text="", origin=(0, 0), scale=2.5,
                                color=color.red, position=(0, 0))
        self.hud_scoreboard = Text(text="", position=(-0.4, 0.4), scale=1.1,
                                    color=color.white, background=True)
        self.hud_scoreboard.enabled = False

        # Crosshair (ground reticle handled below as 3D)
        self.reticle = Entity(model="circle", color=color.rgba(255, 50, 50, 180),
                               scale=1.4, rotation_x=90, y=0.05)
        # Camera setup: isometric top-down chase
        camera.orthographic = False
        camera.fov = 50
        self.cam_offset = Vec3(0, 22, -14)
        camera.position = self.cam_offset
        camera.rotation = (55, 0, 0)

        # Lighting
        DirectionalLight(parent=scene, y=10, z=-5, rotation=(45, -30, 0), shadows=False)
        AmbientLight(color=color.rgba(150, 150, 180, 255))

        # Input bindings
        self.app.input = self.on_input  # not really how Ursina hooks; we'll use global
        from ursina import application as _app
        _app.development_mode = False

        self.app.update = self.update_loop
        # global input hook
        import ursina
        original = getattr(ursina, "input", None)
        # easier: override module-level input via window event
        from ursina import window as _win
        # we use held_keys for movement; handle clicks/keys via on_input

    # ----- world build (arena, walls, bushes, floor) -----
    def _build_world(self):
        r = self.arena_r
        # Floor (large circle)
        floor = Entity(model="cylinder", color=color.rgb(110, 170, 90),
                        scale=(r*2, 0.2, r*2), position=(0, -0.1, 0))
        # arena ring
        Entity(model="cylinder", color=color.rgb(80, 60, 40),
                scale=(r*2.1, 0.4, r*2.1), position=(0, -0.2, 0))
        # Grid pattern (cheap stripes)
        for i in range(-int(r), int(r) + 1, 4):
            Entity(model="cube", color=color.rgba(255, 255, 255, 18),
                    scale=(r*2, 0.01, 0.05), position=(0, 0.01, i))
            Entity(model="cube", color=color.rgba(255, 255, 255, 18),
                    scale=(0.05, 0.01, r*2), position=(i, 0.01, 0))

        # Walls (cover crates)
        for w in self.net.welcome["walls"]:
            Entity(
                model="cube",
                color=color.rgb(160, 110, 70),
                scale=(w["w"], 1.8, w["h"]),
                position=(w["x"], 0.9, w["z"]),
                texture="white_cube",
            )
            # rim
            Entity(
                model="cube",
                color=color.rgb(90, 60, 40),
                scale=(w["w"]*1.05, 0.2, w["h"]*1.05),
                position=(w["x"], 1.85, w["z"]),
            )

        # Bushes
        for b in self.net.welcome["bushes"]:
            base = Entity(
                model="sphere",
                color=color.rgb(40, 130, 50),
                scale=(b["r"]*2, 1.4, b["r"]*2),
                position=(b["x"], 0.4, b["z"]),
            )
            Entity(parent=base, model="sphere",
                   color=color.rgb(70, 160, 70),
                   scale=(0.6, 0.6, 0.6),
                   position=(0.3, 0.3, 0.3))
            Entity(parent=base, model="sphere",
                   color=color.rgb(70, 160, 70),
                   scale=(0.5, 0.5, 0.5),
                   position=(-0.3, 0.3, -0.2))

    # ----- input -----
    def on_input(self, key):
        pass  # not used; we use held_keys + Ursina's global input via overrides

    # ----- main loop -----
    def update_loop(self):
        dt = utime.dt
        if not self.net.connected:
            self.hud_center.text = f"Disconnected: {self.net.error or ''}"
            return

        # snapshot server state
        with self.net.lock:
            state = self.net.state

        # locate self in state
        me = None
        for pl in state.get("players", []):
            if pl["pid"] == self.net.my_pid:
                me = pl
                break

        # Movement
        dx = (held_keys["d"] + held_keys["right arrow"]) - (held_keys["a"] + held_keys["left arrow"])
        dz = (held_keys["w"] + held_keys["up arrow"]) - (held_keys["s"] + held_keys["down arrow"])
        # Aim: cast ray from mouse to y=0 plane
        if mouse.world_point:
            self.aim_world = Vec3(mouse.world_point.x, 0, mouse.world_point.z)
        # alt: compute via screen ray manually
        else:
            # fallback: use screen direction relative to camera
            mx = mouse.position.x
            my = mouse.position.y
            self.aim_world = Vec3(mx * 20, 0, my * 20)

        # Player yaw (rotation around Y, math convention)
        yaw = 0.0
        if me:
            yaw_dx = self.aim_world.x - me["x"]
            yaw_dz = self.aim_world.z - me["z"]
            yaw = math.atan2(yaw_dx, yaw_dz)

        # Send input ~30Hz
        now = time.time()
        if now - self.last_input_send > 1/30:
            self.net.send_input(dx, dz, now - (self.last_input_send or now), yaw)
            self.last_input_send = now

        # Shoot
        try:
            shooting = (mouse.left or held_keys["space"])
        except Exception:
            shooting = held_keys["space"]
        if shooting and me and me["alive"]:
            stats = self.brawler_stats[me["brawler"]]
            if now - self.last_shot > stats["fire_rate"]:
                self.net.send_shoot(yaw)
                self.last_shot = now

        # Scoreboard toggle
        self.hud_scoreboard.enabled = bool(held_keys["tab"])

        # Update / create player views
        seen = set()
        for pl in state.get("players", []):
            seen.add(pl["pid"])
            if pl["pid"] not in self.player_views:
                self.player_views[pl["pid"]] = PlayerView(
                    pl["pid"], pl["brawler"], self.brawler_stats[pl["brawler"]]
                )
            pv = self.player_views[pl["pid"]]
            pv.update_from(pl, self.brawler_stats[pl["brawler"]])
        # remove gone
        for pid in list(self.player_views.keys()):
            if pid not in seen:
                self.player_views[pid].destroy()
                del self.player_views[pid]
        # lerp all
        for pv in self.player_views.values():
            pv.lerp(dt)

        # Projectiles
        seen_p = set()
        for pr in state.get("projectiles", []):
            seen_p.add(pr["oid"])
            if pr["oid"] not in self.proj_views:
                self.proj_views[pr["oid"]] = ProjectileView(pr["oid"], pr["x"], pr["z"], pr["color"])
            else:
                self.proj_views[pr["oid"]].update(pr["x"], pr["z"])
        for oid in list(self.proj_views.keys()):
            if oid not in seen_p:
                self.proj_views[oid].destroy()
                del self.proj_views[oid]

        # Camera follow
        if me:
            target = Vec3(me["x"] + self.cam_offset.x,
                          self.cam_offset.y,
                          me["z"] + self.cam_offset.z)
            camera.position = camera.position + (target - camera.position) * min(1, dt * 6)
            camera.look_at(Vec3(me["x"], 0, me["z"] + 2))

        # Reticle
        self.reticle.position = (self.aim_world.x, 0.06, self.aim_world.z)

        # HUD
        if me:
            stats = self.brawler_stats[me["brawler"]]
            hp_txt = f"HP {int(me['hp'])}/{int(me['max_hp'])}"
            self.hud_status.text = (
                f"<{me['brawler'].upper()}>  {hp_txt}\n"
                f"K {me['kills']}  D {me['deaths']}  Players online: {len(state.get('players', []))}"
            )
            if not me["alive"]:
                self.hud_center.text = f"You died — respawn in {me['respawn_in']:.1f}s"
                self.hud_center.color = color.red
            else:
                self.hud_center.text = ""
        # Scoreboard
        rows = sorted(state.get("players", []),
                      key=lambda p: (-p["kills"], p["deaths"]))
        sb_lines = ["── SCOREBOARD (Tab) ──", f"{'Name':<14}{'Brawler':<10}{'K':>3}{'D':>4}"]
        for pl in rows:
            mark = "*" if pl["pid"] == self.net.my_pid else " "
            sb_lines.append(f"{mark}{pl['name'][:13]:<13}{pl['brawler'][:9]:<10}"
                             f"{pl['kills']:>3}{pl['deaths']:>4}")
        self.hud_scoreboard.text = "\n".join(sb_lines)

    def run(self):
        # ESC = quit
        from ursina import application
        def _ihook(key):
            if key == "escape":
                application.quit()
        # Ursina uses module-level input(); easiest is to monkeypatch __main__ namespace.
        import builtins
        builtins.input = _ihook  # no — input() is dangerous to override
        # Instead use window's exit hook
        try:
            window.exit_button.visible = True
        except Exception:
            pass
        self.app.run()


def select_brawler_cli():
    print("\nAvailable brawlers:")
    names = ["spike", "edgar", "buzz", "damian", "lumi", "sirius", "alli", "kaze", "kit"]
    for i, n in enumerate(names, 1):
        print(f"  {i}. {n}")
    while True:
        s = input("Pick a brawler (name or number, default spike): ").strip().lower()
        if not s:
            return "spike"
        if s.isdigit() and 1 <= int(s) <= len(names):
            return names[int(s) - 1]
        if s in names:
            return s


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=5555)
    ap.add_argument("--name", default=f"P{os.getpid() % 1000}")
    ap.add_argument("--brawler", default=None,
                     choices=["spike", "edgar", "buzz", "damian", "lumi",
                              "sirius", "alli", "kaze", "kit"])
    ap.add_argument("--no-prompt", action="store_true")
    args = ap.parse_args()
    if not args.brawler and not args.no_prompt:
        args.brawler = select_brawler_cli()
    elif not args.brawler:
        args.brawler = "spike"
    g = Game(args)
    g.run()


if __name__ == "__main__":
    main()
